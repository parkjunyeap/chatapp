const chatController = require("../Controllers/chat.controller");
const userController = require("../Controllers/user.controller");

module.exports = function (io) {
  //io~~~
  io.on("connection", async (socket) => {
    console.log("클라이언트와 연결됐습니다.", socket.id);

    socket.on("login", async (userName, cb) => {
      try {
        const user = await userController.saveUser(userName, socket.id);
        const welcomeMessage = {
          chat: `${user.name} 님이 들어왔습니다`,
          user: { id: null, name: "system" },
        };
        io.emit("message", welcomeMessage);
        cb({ ok: true, data: user });
      } catch (error) {
        cb({ ok: false, error: error.message });
      }
    }); // 대화 제목 , 로그인을 들었을때 하고싶은 내용
    // 매개변수로 콜백함수도 받을 수 있음.
    socket.on("sendMessage", async (message, cb) => {
      try {
        // 소켓 id로 유저 찾기
        const user = await userController.checkUser(socket.id);
        // 메시지 저장(유저)
        const newMessage = await chatController.saveChat(message, user);

        // 메시지 모두에게 전송
        io.emit("message", newMessage);
        cb({ ok: true });
      } catch (error) {
        cb({ ok: false, error: error.message });
      }
    });

    socket.on("disconnect", () => {
      console.log("유저와 연결이 끊겼습니다.");
    });
    // 연결된 사람 socket
  });
};

//emit 말하기
// on 듣기
