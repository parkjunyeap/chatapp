const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config(); // env파일
const cors = require("cors"); // 백엔드 프론트엔드 연결 위함
const app = express();
app.use(cors());

mongoose
  .connect(process.env.DB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("데이터베이스 연동 성공"));

module.exports = app;
