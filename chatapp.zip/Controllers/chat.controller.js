const Chat = require("../Models/chat");
const chatController = {};

chatController.saveChat = async (message, user) => {
  const newMessage = new Chat({
    chat: message,
    user: {
      id: user._id, // _ 몽고디비에서 아이디
      name: user.name,
    },
  });

  await newMessage.save();
  return newMessage;
};

module.exports = chatController;
