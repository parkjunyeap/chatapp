const User = require("../Models/user");
const userController = {};

userController.saveUser = async (userName, sid) => {
  // 이미있는 유저인지 확인

  let user = await User.findOne({ name: userName });

  // 없다면 유저정보 만듦

  if (!user) {
    user = new User({
      name: userName,
      token: sid,
      online: true,
    });
  }

  // 이미 있는 유저라면
  user.token = sid;
  user.online = true;

  await user.save();
  return user;
};

userController.checkUser = async (sid) => {
  const user = await User.findOne({ token: sid });
  if (!user) throw new Error("해당하는 유저가 없다");
  return user;
};
module.exports = userController;
