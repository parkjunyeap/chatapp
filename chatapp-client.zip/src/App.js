import { useEffect } from "react";
import "./App.css";
import socket from "./server";
import InputField from "./components/InputField/InputField";
import { useState } from "react";
import MessageContainer from "./components/MessageContainer/MessageContainer";

function App() {
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const [messageList, setMessageList] = useState([]);
  console.log("message List", messageList);
  useEffect(() => {
    socket.on("message", (message) => {
      setMessageList((prevState) => prevState.concat(message));
    });
    askUserName();
  }, []);

  const askUserName = () => {
    const userName = prompt("이름을 입력하세요");
    console.log("유저네임", userName);

    socket.emit("login", userName, (res) => {
      console.log("res", res); // 왜 data 가 안오지 ?
      if (res?.ok) {
        setUser(res.data);
      }
    }); // 프론트에서 유저이름이 이거야~
    // 대화제목, 보낼내용, 콜백함수
  }; // 시작하자마자 이름 입력받기

  const sendMessage = (event) => {
    event.preventDefault();
    socket.emit("sendMessage", message, (res) => {
      console.log("send메시지 ", res);
    }); // 입력받은 메시지
  };
  return (
    <div>
      <div className="App">
        <MessageContainer messageList={messageList} user={user} />
        <InputField
          message={message}
          setMessage={setMessage}
          sendMessage={sendMessage}
        />
      </div>
    </div>
  );
}

export default App;
