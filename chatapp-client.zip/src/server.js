import { io } from "socket.io-client";
const socket = io("http://localhost:5001"); // 백엔드에 연결할수있는 소켓
export default socket;
